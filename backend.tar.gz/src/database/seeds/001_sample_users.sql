-- 샘플 사용자 데이터
-- 개발 및 테스트용 사용자 정보

INSERT INTO users (age, gender, activity) VALUES
(25, 'male', 'medium'),
(30, 'female', 'high'),
(35, 'male', 'low'),
(28, 'female', 'medium'),
(40, 'male', 'high');
